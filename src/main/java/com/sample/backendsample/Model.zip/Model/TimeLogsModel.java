package com.sample.backendsample.Model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class TimeLogsModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long timelog_id;
    private String taskId;
    private String userId;
    private Date startTime; 
    private Date endTime;
    private long duration; 
}
