package com.sample.backendsample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusRepo extends JpaRepository<StatusRepo, Long> {
}
