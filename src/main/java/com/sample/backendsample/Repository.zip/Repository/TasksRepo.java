package com.sample.backendsample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.backendsample.Model.TasksModel;

public interface TasksRepo extends JpaRepository< TasksModel, Long> {
    
}
