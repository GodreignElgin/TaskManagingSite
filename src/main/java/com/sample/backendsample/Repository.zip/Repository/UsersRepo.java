package com.sample.backendsample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.backendsample.Model.UsersModel;

public interface UsersRepo extends JpaRepository<UsersModel, Long> {
}
