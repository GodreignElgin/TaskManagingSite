package com.sample.backendsample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.backendsample.Model.TimeLogsModel;

public interface TimeLogsRepo extends JpaRepository<TimeLogsModel, Long> { 
}
