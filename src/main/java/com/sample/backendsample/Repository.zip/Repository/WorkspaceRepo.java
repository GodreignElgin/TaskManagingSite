package com.sample.backendsample.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.backendsample.Model.WorkspacesModel;

public interface WorkspaceRepo extends JpaRepository<WorkspacesModel, Long> {
}
